#ifndef __DETECT_TASK_H_
#define __DETECT_TASK_H_

void Detect_Task(void *pvParameters);

#endif
