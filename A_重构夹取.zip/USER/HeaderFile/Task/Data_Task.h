#ifndef __DATA_TASK_H_
#define __DATA_TASK_H_

void Data_Task(void *pvParameters);

#endif
