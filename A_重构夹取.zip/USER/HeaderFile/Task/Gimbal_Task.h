#ifndef __GIMBAL_TASK_H_
#define __GIMBAL_TASK_H_

void Gimbal_Task(void *pvParameters);

#endif
