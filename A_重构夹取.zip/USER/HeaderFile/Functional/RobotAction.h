#ifndef __ROBOTACTION_H_
#define __ROBOTACTION_H_

#include  "GraspMotor.h"
#include  "MotorAction.h" 



void Auto_Ctrl(Gr_t *Gr,u8 box);		/*�Զ�����*/
void Reset(Gr_t *Gr);

#endif
