#ifndef __GETGOLD_H_
#define __GETGOLD_H_

#include "MotorAction.h"
#include "GraspMotor.h"


static void goldExchange(Gr_t *Gr) ;
void Auto_Gold(Gr_t *Gr);
#endif 

